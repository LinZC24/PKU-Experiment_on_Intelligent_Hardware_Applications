import RPi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BCM)

light = 26
GPIO.setup(light, GPIO.OUT)
p = GPIO.PWM(light, 50)
p.start(0)

try:
    while True:
        for dc in range(0, 101, 2):
            p.ChangeDutyCycle(dc)
            time.sleep(0.02)
        for dc in range(100, -1, -2):
            p.ChangeDutyCycle(dc)
            time.sleep(0.02)
except KeyboardInterrupt:
    pass
    p.stop()
    GPIO.cleanup()
finally:
    pass
    p.stop()
    GPIO.cleanup()