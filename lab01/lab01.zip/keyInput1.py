import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)

key = 20
light = 26
lighter = True
GPIO.setup(light, GPIO.OUT)
GPIO.setup(key, GPIO.IN, GPIO.PUD_UP)
p = GPIO.PWM(light, 50)
p.start(0)

def my_callback(ch):
    global lighter
    if lighter == True:
        lighter = False
    else:
        lighter = True
GPIO.add_event_detect(key, GPIO.RISING, callback = my_callback, bouncetime = 200)

try:
    while True:
        if lighter == True:
            for dc in range(0, 101, 2):
                p.ChangeDutyCycle(dc)
                time.sleep(0.05)
            p.ChangeDutyCycle(0)
        elif lighter == False:
            for dc in range(100, -1, -2):
                p.ChangeDutyCycle(dc)
                time.sleep(0.05)
            p.ChangeDutyCycle(100)
finally:
    p.stop()
    GPIO.cleanup()