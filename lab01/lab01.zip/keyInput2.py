import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)

key = 20
led = 26
freq = 1
t = 0
stop = False
light = False

GPIO.setup(led, GPIO.OUT, initial = GPIO.LOW)
GPIO.setup(key, GPIO.IN, GPIO.PUD_UP)

def my_callback(ch):
    global t
    global stop
    global freq
    global light
    if stop == False and GPIO.input(led) == GPIO.LOW:
        light = True
    else:
        freq = freq / 2
    if (time.time() - t) < 0.5:
        stop = True
        light = False
        #return
    else:
        t = time.time()
GPIO.add_event_detect(key, GPIO.RISING, callback = my_callback, bouncetime = 50)

try:
    while True:
        if light:
            GPIO.output(led, GPIO.HIGH)
            time.sleep(freq)
            GPIO.output(led, GPIO.LOW)
            time.sleep(freq)
        elif stop:
            GPIO.output(led, GPIO.LOW)
            freq = 2
except KeyboardInterrupt:
    GPIO.cleanup()
finally:
    GPIO.cleanup()